from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import random
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import wraps
from typing import (
    Annotated,
    Any,
    Generic,
    Literal,
    TypeVar,
    cast,
    final,
    get_args,
    get_origin,
    overload,
)

import httpx
from openai import AsyncStream
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionMessage,
    ChatCompletionMessageToolCall,
)
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_message_custom_tool_call import (
    ChatCompletionMessageCustomToolCall,
)
from openai.types.chat.chat_completion_message_function_tool_call import (
    ChatCompletionMessageFunctionToolCall,
    Function as ToolCallFunction,
)
from pydantic import BaseModel

from factorial.core.events import AgentEvent, EventPublisher
from factorial.core.exceptions import (
    RETRYABLE_EXCEPTIONS,
    FatalAgentError,
    InvalidLLMResponseError,
    VerificationRejected,
)
from factorial.core.logging import get_logger
from factorial.core.utils import (
    is_valid_task_id,
    serialize_data,
    to_snake_case,
    validate_callback_signature as _vcs,
)
from factorial.execution.context import (
    AgentContext,
    ContextType,
    ExecutionContext,
    execution_context,
)
from factorial.execution.hooks import (
    HookRequestContext,
    HookSessionNode,
    HookSessionRecord,
    PendingHook,
    build_request_builder_kwargs,
)
from factorial.execution.tools import (
    ToolDefinition,
    _ToolResultInternal,
    convert_tools_list,
    create_final_output_tool,
    serialize_for_client,
    serialize_for_model,
)
from factorial.execution.waits import WaitInstruction
from factorial.llm.models import Model, MultiClient

logger = get_logger(__name__)

T = TypeVar("T")


async def _invoke_callable_non_blocking(
    fn: Callable[..., Any],
    *args: Any,
    **kwargs: Any,
) -> Any:
    """Invoke callback without blocking the event loop.

    Async callbacks are awaited directly. Sync callbacks are always executed in a
    worker thread so tool and hook callback code cannot stall heartbeats.
    """
    if asyncio.iscoroutinefunction(fn):
        async_fn = cast(Callable[..., Awaitable[Any]], fn)
        return await async_fn(*args, **kwargs)
    return await asyncio.to_thread(fn, *args, **kwargs)


@overload
def retry(
    func: Callable[..., Awaitable[T]],
) -> Callable[..., Awaitable[T]]: ...


@overload
def retry(
    func: None = None,
    *,
    max_attempts: int = 3,
    delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: bool = True,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]: ...


def retry(
    func: Callable[..., Awaitable[T]] | None = None,
    *,
    max_attempts: int = 3,
    delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: bool = True,
) -> (
    Callable[..., Awaitable[T]]
    | Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]
):
    """Decorator to add retry logic to agent methods.

    Can be used as a decorator with or without arguments:

    @retry
    async def my_method(self, ...):
        ...

    @retry(max_attempts=5, delay=2.0)
    async def my_method(self, ...):
        ...
    """

    def _create_retry_decorator(
        the_func: Callable[..., Awaitable[T]],
    ) -> Callable[..., Awaitable[T]]:
        # ------------------------------------------------------------------
        # Determine which parameter (if any) represents the AgentContext so we
        # can update its ``attempt`` field on each retry.  We do this *once* at
        # decoration time to avoid repeated introspection.
        # ------------------------------------------------------------------

        sig = inspect.signature(the_func)

        _ctx_param_name: str | None = None
        _ctx_pos: int | None = None  # Positional index of the context parameter

        for idx, param in enumerate(sig.parameters.values()):
            ann = param.annotation
            if (
                ann is not inspect.Parameter.empty
                and isinstance(ann, type)
                and issubclass(ann, AgentContext)
            ):
                _ctx_param_name = param.name
                _ctx_pos = idx - 1  # subtract 1 to account for ``self``
                break

        # Fallback to conventional name if annotation is missing.
        if _ctx_param_name is None and "agent_ctx" in sig.parameters:
            _ctx_param_name = "agent_ctx"
            _ctx_pos = list(sig.parameters).index("agent_ctx") - 1

        # If still None, the wrapped function doesn't take an AgentContext; we
        # can skip all bookkeeping in that case.

        @wraps(the_func)
        async def wrapper(self: BaseAgent[Any], *args: Any, **kwargs: Any) -> T:
            if max_attempts <= 0:
                raise ValueError("max_attempts must be greater than 0")

            # --------------------------------------------------------------
            # Resolve the AgentContext **once** per invocation so we don't
            # repeat the same extraction logic on every retry attempt.  The
            # reference is reused within the loop so we only update its
            # ``attempt`` field each iteration.
            # --------------------------------------------------------------
            agent_ctx_obj: Any | None = None
            if _ctx_param_name is not None:
                # Prefer keyword argument – fastest lookup.
                if _ctx_param_name in kwargs:
                    agent_ctx_obj = kwargs[_ctx_param_name]
                # Fallback to positional args tuple.
                elif _ctx_pos is not None and _ctx_pos < len(args):
                    agent_ctx_obj = args[_ctx_pos]

            last_exception: Exception | None = None
            for attempt in range(max_attempts):
                # Best-effort: annotate the current attempt on the context so
                # downstream helpers (e.g. model fallbacks) can react.
                if agent_ctx_obj is not None and isinstance(
                    agent_ctx_obj, AgentContext
                ):
                    try:
                        agent_ctx_obj.attempt = attempt
                    except Exception:
                        # Never let bookkeeping failure break the retry logic.
                        pass

                try:
                    return await the_func(self, *args, **kwargs)
                except Exception as e:
                    if isinstance(e, RETRYABLE_EXCEPTIONS):
                        last_exception = e
                        if attempt < max_attempts - 1:
                            backoff_delay = min(
                                delay * (exponential_base**attempt), max_delay
                            )
                            if jitter:
                                backoff_delay *= random.uniform(0.5, 1.5)
                            await asyncio.sleep(backoff_delay)
                    else:
                        raise e

            raise last_exception or Exception("Retry failed")

        return wrapper

    # If func is provided, we were used as @retry (no parentheses)
    if func is not None:
        return _create_retry_decorator(func)

    # Otherwise, we were used as @retry(...), so return a decorator
    return _create_retry_decorator


@overload
def publish_progress(
    func: Callable[..., Awaitable[T]],
) -> Callable[..., Awaitable[T]]: ...


@overload
def publish_progress(
    func: None = None,
    *,
    func_name: str | None = None,
    include_context: bool = True,
    include_args: bool = True,
    include_result: bool = True,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]: ...


def publish_progress(
    func: Callable[..., Awaitable[T]] | None = None,
    *,
    func_name: str | None = None,
    include_context: bool = True,
    include_args: bool = True,
    include_result: bool = True,
) -> (
    Callable[..., Awaitable[T]]
    | Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]
):
    """Decorator to publish progress events for agent methods.

    Can be used as a decorator with or without arguments:

    @publish_progress
    async def my_method(self, ...):
        ...

    @publish_progress(func_name="custom_name", include_result=False)
    async def my_method(self, ...):
        ...
    """

    def _create_progress_decorator(
        the_func: Callable[..., Awaitable[T]],
    ) -> Callable[..., Awaitable[T]]:
        actual_func_name = func_name or getattr(the_func, "__name__", "unknown")

        @wraps(the_func)
        async def wrapper(self: BaseAgent[Any], *args: Any, **kwargs: Any) -> T:
            async def publish(
                event_suffix: str,
                data: dict[str, Any] | None = None,
                error: str | None = None,
            ) -> None:
                try:
                    ctx = ExecutionContext.current()

                    event_data: dict[str, Any] = {}
                    if data:
                        event_data.update(data)
                    if include_context and ctx:
                        event_data["context"] = ctx

                    await ctx.events.publish_event(
                        AgentEvent(
                            event_type=f"progress_update_{actual_func_name}_{event_suffix}",
                            task_id=ctx.task_id,
                            owner_id=ctx.owner_id,
                            agent_name=self.name,
                            data=serialize_data(event_data) if event_data else None,
                            error=error,
                        )
                    )
                except Exception:
                    logger.exception("Failed to publish progress update", exc_info=True)
                    pass

            start_data: dict[str, Any] = {}
            if include_args:
                start_data.update(
                    {
                        "args": args,
                        "kwargs": kwargs,
                    }
                )
            await publish("started", start_data)

            try:
                result = await the_func(self, *args, **kwargs)

                completion_data: dict[str, Any] = {}
                if include_args:
                    completion_data.update(
                        {
                            "args": args,
                            "kwargs": kwargs,
                        }
                    )
                if include_result:
                    completion_data["result"] = serialize_data(result)

                await publish("completed", completion_data if completion_data else None)
                return result
            except Exception as e:
                failed_data: dict[str, Any] = {}
                if include_args:
                    failed_data.update(
                        {
                            "args": args,
                            "kwargs": kwargs,
                        }
                    )
                await publish(
                    "failed", failed_data if failed_data else None, error=str(e)
                )
                raise

        return wrapper

    # If func is provided, we were used as @publish_progress (no parentheses)
    if func is not None:
        return _create_progress_decorator(func)

    # Otherwise, we were used as @publish_progress(...), so return a decorator
    return _create_progress_decorator


@dataclass
class TurnCompletion(Generic[ContextType]):
    is_done: bool
    context: ContextType
    output: Any = None
    tool_call_results: list[tuple[ChatCompletionMessageToolCall, Any | Exception]] = (
        field(default_factory=list)
    )
    pending_tool_call_ids: list[str] = field(default_factory=list)
    pending_child_task_ids: list[str] = field(default_factory=list)


@dataclass
class RunCompletion(Generic[ContextType]):
    """Summary object for the *entire* run passed to ``on_run_end``.

    Timestamps are stored instead of a raw *duration* so consumers can
    calculate different metrics, and we expose a convenience ``duration``
    property.
    """

    output: Any | None
    started_at: datetime
    finished_at: datetime
    error: Exception | None = None

    @property
    def duration(self) -> float:
        """Runtime in **seconds**."""

        return (self.finished_at - self.started_at).total_seconds()

    @property
    def succeeded(self) -> bool:
        return self.error is None


@dataclass
class ModelSettings(Generic[ContextType]):
    temperature: float | Callable[[ContextType], float] | None = None
    tool_choice: (
        str
        | dict[str, Any]
        | Callable[[ContextType], str | dict[str, Any] | None]
        | None
    ) = None
    parallel_tool_calls: bool | Callable[[ContextType], bool] | None = None
    max_completion_tokens: int | Callable[[ContextType], int] | None = None

    def resolve(self, agent_ctx: ContextType) -> ResolvedModelSettings:
        return ResolvedModelSettings(
            temperature=self.temperature(agent_ctx)
            if callable(self.temperature)
            else self.temperature,
            tool_choice=self.tool_choice(agent_ctx)
            if callable(self.tool_choice)
            else self.tool_choice,
            parallel_tool_calls=self.parallel_tool_calls(agent_ctx)
            if callable(self.parallel_tool_calls)
            else self.parallel_tool_calls,
            max_completion_tokens=self.max_completion_tokens(agent_ctx)
            if callable(self.max_completion_tokens)
            else self.max_completion_tokens,
        )


@dataclass
class ResolvedModelSettings:
    temperature: float | None
    tool_choice: str | dict[str, Any] | None
    parallel_tool_calls: bool | None
    max_completion_tokens: int | None


@dataclass
class ToolExecutionResults:
    new_messages: list[dict[str, Any]]
    tool_call_results: list[tuple[ChatCompletionMessageToolCall, Any | Exception]]
    pending_tool_call_ids: list[str]
    pending_child_task_ids: list[str]


class BaseAgent(Generic[ContextType]):
    def __init__(
        self,
        name: str | None = None,
        instructions: str | Callable[..., str] | None = None,
        description: str | None = None,
        tools: list[ToolDefinition[ContextType] | Callable[..., Any]] | None = None,
        model: Model | Callable[[ContextType], Model] | None = None,
        model_settings: ModelSettings[ContextType] | None = None,
        stream: bool = False,
        context_window_limit: int | None = None,
        max_turns: int | None = None,
        http_client: httpx.AsyncClient | None = None,
        client: MultiClient | None = None,
        request_timeout: float = 120.0,
        parse_tool_args: bool = True,
        context_class: type = AgentContext,
        output_type: type[BaseModel] | None = None,
        verifier: Callable[..., Any] | None = None,
        verifier_max_attempts: int = 3,
        # ---- Lifecycle callbacks ---- #
        on_run_start: Callable[[ContextType, ExecutionContext], Awaitable[None] | None]
        | None = None,
        on_run_end: Callable[
            [ContextType, ExecutionContext, RunCompletion[ContextType]],
            Awaitable[None] | None,
        ]
        | None = None,
        on_turn_start: Callable[[ContextType, ExecutionContext], Awaitable[None] | None]
        | None = None,
        on_turn_end: Callable[
            [ContextType, ExecutionContext, TurnCompletion[ContextType]],
            Awaitable[None] | None,
        ]
        | None = None,
        on_pending_tool_call: Callable[
            [ContextType, ExecutionContext, ChatCompletionMessageToolCall],
            Awaitable[None] | None,
        ]
        | None = None,
        on_pending_tool_results: Callable[
            [ContextType, ExecutionContext, list[tuple[str, Any]]],
            Awaitable[None] | None,
        ]
        | None = None,
        on_run_cancelled: Callable[
            [ContextType, ExecutionContext], Awaitable[None] | None
        ]
        | None = None,
    ):
        self.name = to_snake_case(name or self.__class__.__name__)
        self.description = description or self.__class__.__name__
        self.instructions = instructions
        self.tools, self.tool_actions = convert_tools_list(tools or [])
        self.http_client = http_client or httpx.AsyncClient(timeout=request_timeout)
        self.client = client or MultiClient(http_client=self.http_client)
        self.request_timeout = request_timeout
        self.event_publisher: EventPublisher | None = None
        self.model = model
        self.model_settings = model_settings or ModelSettings()
        self.stream = stream
        self.context_window_limit = context_window_limit
        self.max_turns = max_turns
        self.parse_tool_args = parse_tool_args
        self.context_class = context_class
        self.output_type = output_type
        self.verifier = verifier
        self.verifier_max_attempts = verifier_max_attempts
        self.final_output_tool = (
            create_final_output_tool(self.output_type) if self.output_type else None
        )

        if self.verifier is not None and not callable(self.verifier):
            raise TypeError("verifier must be callable")
        if self.verifier_max_attempts <= 0:
            raise ValueError("verifier_max_attempts must be greater than 0")
        if self.verifier is not None and (
            self.output_type is None
            or not isinstance(self.output_type, type)
            or not issubclass(self.output_type, BaseModel)
        ):
            raise ValueError(
                "verifier requires output_type to be a Pydantic BaseModel subclass"
            )

        # Lifecycle callbacks
        self.on_run_start = on_run_start
        self.on_run_end = on_run_end
        self.on_turn_start = on_turn_start
        self.on_turn_end = on_turn_end
        self.on_pending_tool_call = on_pending_tool_call
        self.on_pending_tool_results = on_pending_tool_results
        self.on_run_cancelled = on_run_cancelled

        # --- Validate lifecycle callback signatures --- #
        _vcs("on_run_start", self.on_run_start, (AgentContext, ExecutionContext))
        _vcs("on_turn_start", self.on_turn_start, (AgentContext, ExecutionContext))
        _vcs(
            "on_turn_end",
            self.on_turn_end,
            (AgentContext, ExecutionContext, TurnCompletion),
        )
        _vcs(
            "on_run_end",
            self.on_run_end,
            (AgentContext, ExecutionContext, RunCompletion),
        )
        _vcs(
            "on_pending_tool_call",
            self.on_pending_tool_call,
            (AgentContext, ExecutionContext, ChatCompletionMessageToolCall),
        )
        _vcs(
            "on_pending_tool_results",
            self.on_pending_tool_results,
            (AgentContext, ExecutionContext, list),
        )
        _vcs(
            "on_run_cancelled",
            self.on_run_cancelled,
            (AgentContext, ExecutionContext),
        )

    # ===== Overridable Methods ===== #

    async def validate_completion(
        self,
        agent_ctx: ContextType,
        response: ChatCompletion,
    ) -> None:
        """Validate the completion response.

        Raise an InvalidLLMResponseError if the response is invalid.
        """
        pass

    async def completion(
        self,
        agent_ctx: ContextType,
        messages: list[dict[str, Any]],
    ) -> ChatCompletion:
        """Execute LLM completion. Override to customize."""
        model_settings = self.resolve_model_settings(agent_ctx)
        tools = self.resolve_tools(agent_ctx)
        model = self.resolve_model(agent_ctx)

        execution_ctx = ExecutionContext.current()

        # If max_turns is set, force the agent to finish on the final turn.
        is_last_turn = (
            self.max_turns is not None and agent_ctx.turn >= self.max_turns - 1
        )

        if is_last_turn:
            if self.final_output_tool is not None:
                model_settings.tool_choice = {
                    "type": "function",
                    "function": {"name": "final_output"},
                }
            else:
                model_settings.tool_choice = "none"

        if not self.stream:
            response = cast(
                ChatCompletion,
                await self.client.completion(
                    model=model,
                    messages=messages,
                    tools=tools,
                    temperature=model_settings.temperature,
                    max_completion_tokens=model_settings.max_completion_tokens,
                    tool_choice=model_settings.tool_choice,
                    parallel_tool_calls=model_settings.parallel_tool_calls,
                ),
            )
            await self.validate_completion(agent_ctx, response)
        else:
            # progressively reconstruct both the assistant text content
            # *and* any tool calls (potentially multiple)

            content: str = ""
            # tool-call index -> partial data
            tool_call_acc: dict[int, dict[str, Any]] = {}

            res_id: str = ""
            created_ts: int | None = None
            finish_reason: Literal[
                "stop", "length", "tool_calls", "content_filter", "function_call"
            ] | None = None
            usage: Any | None = None  # ``usage`` is populated in the last chunk

            res = cast(
                AsyncStream[ChatCompletionChunk],
                await self.client.completion(
                    model=model,
                    messages=messages,
                    tools=tools,
                    temperature=model_settings.temperature,
                    max_completion_tokens=model_settings.max_completion_tokens,
                    tool_choice=model_settings.tool_choice,
                    parallel_tool_calls=model_settings.parallel_tool_calls,
                    stream=True,
                ),
            )

            async for chunk in res:
                res_id = chunk.id
                created_ts = chunk.created
                delta = chunk.choices[0].delta

                if delta.content:
                    content += delta.content

                # Accumulate tool call deltas (could be multiple per chunk)
                if delta.tool_calls:
                    for delta_tool in delta.tool_calls:
                        idx = delta_tool.index or 0

                        acc = tool_call_acc.setdefault(
                            idx,
                            {
                                "id": None,
                                "type": None,
                                "name": None,
                                "arguments": "",
                            },
                        )

                        # Static fields can arrive anytime – keep first non-None.
                        if delta_tool.id is not None:
                            acc["id"] = delta_tool.id
                        if delta_tool.type is not None:
                            acc["type"] = delta_tool.type

                        # Function fragment (name/arguments)
                        if delta_tool.function:
                            if delta_tool.function.name is not None:
                                acc["name"] = delta_tool.function.name
                            if delta_tool.function.arguments:
                                acc["arguments"] += delta_tool.function.arguments

                # Capture finish reason (set in the last chunk)
                if chunk.choices[0].finish_reason is not None:
                    finish_reason = chunk.choices[0].finish_reason

                # Capture usage if provided (usually only in last chunk)
                if chunk.usage is not None:
                    usage = chunk.usage

                # Publish progress update for this chunk (streaming)
                try:
                    if execution_ctx and execution_ctx.events:
                        await execution_ctx.events.publish_event(
                            AgentEvent(
                                event_type="progress_update_completion_chunk",
                                task_id=execution_ctx.task_id,
                                owner_id=execution_ctx.owner_id,
                                agent_name=self.name,
                                turn=agent_ctx.turn,
                                data=serialize_data(chunk),
                            )
                        )
                except Exception:
                    logger.exception(
                        "Failed to publish streaming progress update", exc_info=True
                    )

            # Convert accumulated tool call data into the structured OpenAI type
            formatted_tool_calls: (
                list[
                    ChatCompletionMessageFunctionToolCall
                    | ChatCompletionMessageCustomToolCall
                ]
                | None
            ) = None
            if tool_call_acc:
                formatted_tool_calls = []
                for idx in sorted(tool_call_acc.keys()):
                    acc = tool_call_acc[idx]
                    if acc["name"] is None:
                        # Incomplete tool call – skip for safety (shouldn't happen)
                        logger.debug(
                            "Incomplete tool call: %s",
                            acc,
                        )
                        continue
                    formatted_tool_calls.append(
                        ChatCompletionMessageToolCall(
                            id=acc["id"] or f"call_{idx}",
                            type=acc["type"] or "function",
                            function=ToolCallFunction(
                                name=acc["name"],
                                arguments=acc["arguments"],
                            ),
                        )
                    )

            response = ChatCompletion(
                id=res_id,
                model=model.name,
                created=created_ts or int(datetime.now().timestamp()),
                object="chat.completion",
                choices=[
                    Choice(
                        index=0,
                        message=ChatCompletionMessage(
                            role="assistant",
                            content=content or None,
                            tool_calls=formatted_tool_calls,
                        ),
                        finish_reason=finish_reason or "stop",
                    )
                ],
                usage=usage,
            )

        return response

    async def tool_action(
        self,
        tool_call: ChatCompletionMessageToolCall,
        agent_ctx: ContextType,
    ) -> _ToolResultInternal:
        """Execute a tool action. Override to customize."""
        tool_name = tool_call.function.name
        tool_args = tool_call.function.arguments
        action = self.tool_actions.get(tool_name)
        tool_def = next((tool for tool in self.tools if tool.name == tool_name), None)
        hook_plan = tool_def.hook_plan if tool_def else None

        execution_ctx = ExecutionContext.current()

        if not action:
            raise ValueError(f"Agent {self.name} has no tool action for {tool_name}")

        is_forking_tool = getattr(action, "forking_tool", False)

        if not self.parse_tool_args:
            result = await _invoke_callable_non_blocking(action, tool_args, agent_ctx)

        else:
            raw_tool_args = json.loads(tool_args)
            parsed_tool_args = dict(raw_tool_args)

            for param_name, param in inspect.signature(action).parameters.items():
                # Skip if the argument is already provided by the LLM call
                if param_name in parsed_tool_args:
                    continue

                # Case 1: Parameter named 'agent_ctx'
                if param_name == "agent_ctx":
                    parsed_tool_args[param_name] = agent_ctx
                    continue

                # Case 2: Parameter type is a subclass of AgentContext
                if (
                    param.annotation
                    and param.annotation is not inspect.Parameter.empty
                    and isinstance(param.annotation, type)
                    and issubclass(param.annotation, AgentContext)
                ):
                    parsed_tool_args[param_name] = agent_ctx
                    continue

                # Case 3: Parameter named 'execution_ctx'
                if param_name == "execution_ctx":
                    parsed_tool_args[param_name] = execution_ctx
                    continue

                # Case 4: Parameter type is a subclass of ExecutionContext
                if (
                    param.annotation
                    and param.annotation is not inspect.Parameter.empty
                    and isinstance(param.annotation, type)
                    and issubclass(param.annotation, ExecutionContext)
                ):
                    parsed_tool_args[param_name] = execution_ctx
                    continue

            # ────────────────────────────────────────────────────────────
            # Second pass: coerce parsed JSON args into Pydantic models.
            # Supports both single ``BaseModel`` parameters and
            # ``list[BaseModel]`` collections.
            # ────────────────────────────────────────────────────────────
            for _pname, _param in inspect.signature(action).parameters.items():
                if _pname not in parsed_tool_args:
                    continue

                _expected = _param.annotation
                if _expected is inspect.Parameter.empty:
                    continue

                try:
                    if get_origin(_expected) is Annotated:
                        _annotated_args = get_args(_expected)
                        if _annotated_args:
                            _expected = _annotated_args[0]

                    _origin = get_origin(_expected)

                    # Case 1 – standalone BaseModel
                    if (
                        isinstance(_expected, type)
                        and issubclass(_expected, BaseModel)
                        and isinstance(parsed_tool_args[_pname], dict)
                    ):
                        parsed_tool_args[_pname] = _expected(**parsed_tool_args[_pname])

                    # Case 2 – list[BaseModel]
                    elif _origin is list:
                        _item_type = (
                            get_args(_expected)[0] if get_args(_expected) else None
                        )
                        if (
                            _item_type
                            and isinstance(_item_type, type)
                            and issubclass(_item_type, BaseModel)
                            and isinstance(parsed_tool_args[_pname], list)
                        ):
                            parsed_tool_args[_pname] = [
                                _item_type(**_it)
                                if not isinstance(_it, _item_type)
                                else _it  # type: ignore[arg-type]
                                for _it in parsed_tool_args[_pname]
                            ]
                except Exception as _e:
                    logger.debug(
                        "Failed to coerce argument '%s' to %s: %s",
                        _pname,
                        _expected,
                        _e,
                    )

            if hook_plan is not None:
                hook_param_names = list(hook_plan.hook_order)
                present_hook_params = [
                    param_name
                    for param_name in hook_param_names
                    if param_name in parsed_tool_args
                ]

                if present_hook_params and len(present_hook_params) != len(
                    hook_param_names
                ):
                    raise ValueError(
                        f"Tool '{tool_name}' continuation received partial hook "
                        f"payloads: {present_hook_params}. Expected all of "
                        f"{hook_param_names}."
                    )

                if not present_hook_params:
                    request_tool_args = {
                        key: parsed_tool_args[key]
                        for key in raw_tool_args.keys()
                        if key in parsed_tool_args
                    }
                    serialized_tool_args = cast(
                        dict[str, Any], serialize_data(request_tool_args)
                    )
                    now_ts = datetime.now(timezone.utc).timestamp()
                    session_seed = (
                        f"{execution_ctx.task_id}:{tool_call.id}:{tool_name}"
                    )
                    session_id = hashlib.sha256(
                        session_seed.encode("utf-8")
                    ).hexdigest()
                    session_nodes: dict[str, HookSessionNode] = {}
                    for hook_param_name in hook_plan.hook_order:
                        node_spec = hook_plan.nodes[hook_param_name]
                        session_nodes[hook_param_name] = HookSessionNode(
                            param_name=hook_param_name,
                            mode=node_spec.mode,
                            hook_type=node_spec.hook_type.__name__,
                            depends_on=node_spec.depends_on,
                        )

                    first_stage = hook_plan.stages[0] if hook_plan.stages else ()
                    if not first_stage:
                        raise ValueError(
                            f"Hook plan for tool '{tool_name}' has no "
                            "requestable stage."
                        )

                    request_ctx = HookRequestContext(
                        task_id=execution_ctx.task_id,
                        owner_id=execution_ctx.owner_id,
                        agent_name=self.name,
                        tool_name=tool_name,
                        tool_call_id=tool_call.id,
                        args=serialized_tool_args,
                    )
                    requested_hooks: list[dict[str, Any]] = []
                    for hook_param_name in first_stage:
                        node_spec = hook_plan.nodes[hook_param_name]
                        request_kwargs = build_request_builder_kwargs(
                            request_builder=node_spec.request_builder,
                            request_ctx=request_ctx,
                            tool_args=request_tool_args,
                            resolved_hook_payloads={},
                        )
                        pending_hook = await _invoke_callable_non_blocking(
                            node_spec.request_builder,
                            **request_kwargs,
                        )
                        if not isinstance(pending_hook, PendingHook):
                            raise TypeError(
                                f"Hook request builder for '{hook_param_name}' must "
                                "return PendingHook[...]"
                            )

                        stable_hook_id = f"{session_id}:{hook_param_name}"
                        pending_hook.hook_id = stable_hook_id

                        node_state = session_nodes[hook_param_name]
                        node_state.status = "requested"
                        node_state.hook_id = stable_hook_id
                        node_state.requested_at = now_ts

                        requested_hooks.append(
                            {
                                "param_name": hook_param_name,
                                "mode": node_spec.mode,
                                "hook_type": node_spec.hook_type.__name__,
                                "depends_on": list(node_spec.depends_on),
                                "hook_id": stable_hook_id,
                                "submit_url": pending_hook.submit_url,
                                "token": pending_hook.token,
                                "expires_at": pending_hook.expires_at.timestamp(),
                                "title": pending_hook.title,
                                "metadata": pending_hook.metadata,
                            }
                        )

                    session = HookSessionRecord(
                        session_id=session_id,
                        task_id=execution_ctx.task_id,
                        tool_call_id=tool_call.id,
                        tool_name=tool_name,
                        tool_args=serialized_tool_args,
                        nodes=session_nodes,
                        status="active",
                        created_at=now_ts,
                        updated_at=now_ts,
                    )

                    await execution_ctx.persist_hook_session(
                        {
                            "kind": "hook_session_init",
                            "session": session.to_dict(),
                            "requested_hooks": requested_hooks,
                        }
                    )
                    return _ToolResultInternal(
                        tool_call=tool_call,
                        model_output="Awaiting hook dependency resolution",
                        client_output={
                            "kind": "hook_session_pending",
                            "session_id": session_id,
                            "requested_hooks": requested_hooks,
                        },
                        pending_result=True,
                    )

            result = await _invoke_callable_non_blocking(action, **parsed_tool_args)

        pending_child_task_ids: list[str] = []
        if is_forking_tool:
            candidate_ids: list[str] | tuple[str, ...] | None

            if isinstance(result, _ToolResultInternal):
                if not result.pending_child_task_ids:
                    raise ValueError(
                        f"Forking tool '{tool_call.function.name}' returned an "
                        "_ToolResultInternal without pending_child_task_ids."
                    )
                candidate_ids = result.pending_child_task_ids
            elif isinstance(result, (list, tuple)) and all(
                isinstance(item, str) for item in result
            ):
                candidate_ids = result
            else:
                raise ValueError(
                    f"Forking tool '{tool_call.function.name}' must return "
                    "list[str] or tuple[str, ...] of task IDs."
                )

            if not all(
                isinstance(item, str) and is_valid_task_id(item)
                for item in candidate_ids
            ):
                raise ValueError(
                    f"Forking tool '{tool_call.function.name}' "
                    f"returned invalid task IDs: {candidate_ids}"
                )
            pending_child_task_ids = list(candidate_ids)

        return self._normalize_tool_result(
            result, tool_call, pending_child_task_ids or None
        )

    @staticmethod
    def _stringify_for_model(value: Any) -> str:
        """Convert arbitrary output into stable model-facing text."""
        if value is None:
            return ""
        if isinstance(value, str):
            return value

        serialized = serialize_data(value)
        if isinstance(serialized, str):
            return serialized
        try:
            return json.dumps(serialized, ensure_ascii=False, sort_keys=True)
        except (TypeError, ValueError):
            return str(serialized)

    @classmethod
    def _wait_model_output(cls, wait_instr: WaitInstruction) -> str:
        """Generate model-facing text for a WaitInstruction."""
        if wait_instr.data is not None:
            if isinstance(wait_instr.data, BaseModel):
                return cls._stringify_for_model(serialize_for_model(wait_instr.data))
            return cls._stringify_for_model(wait_instr.data)
        if wait_instr.kind == "sleep":
            return f"Waiting for {wait_instr.sleep_s or 0}s"
        if wait_instr.kind == "cron":
            expr = wait_instr.cron or "<cron>"
            tz = wait_instr.timezone or "UTC"
            return f"Waiting for next cron tick '{expr}' ({tz})"
        if wait_instr.kind == "jobs":
            return "Waiting for spawned jobs"
        if wait_instr.kind == "activity":
            if (
                wait_instr.activity_timeout_kind == "sleep"
                and wait_instr.activity_timeout_s is not None
            ):
                return (
                    "Waiting for activity or timeout after "
                    f"{wait_instr.activity_timeout_s}s"
                )
            if (
                wait_instr.activity_timeout_kind == "cron"
                and wait_instr.activity_timeout_cron
            ):
                tz = wait_instr.activity_timeout_timezone or "UTC"
                return (
                    "Waiting for activity or next cron tick "
                    f"'{wait_instr.activity_timeout_cron}' ({tz})"
                )
            return "Waiting for activity"
        return "Waiting"

    def _normalize_tool_result(
        self,
        result: Any,
        tool_call: ChatCompletionMessageToolCall,
        pending_child_task_ids: list[str] | None = None,
    ) -> _ToolResultInternal:
        """Normalize any tool return value into _ToolResultInternal.

        Handles the v2 return contract:
        - BaseModel with Hidden fields -> model sees non-hidden, client sees all
        - BaseModel without Hidden -> both see all
        - WaitInstruction -> model sees description, client sees WaitInstruction
        - None -> empty
        - Plain types (str, dict, list, etc.) -> both see the same thing
        """
        if isinstance(result, _ToolResultInternal):
            result.tool_call = tool_call
            if pending_child_task_ids:
                existing = result.pending_child_task_ids or []
                result.pending_child_task_ids = list(
                    dict.fromkeys([*existing, *pending_child_task_ids])
                )
            return result

        if isinstance(result, WaitInstruction):
            return _ToolResultInternal(
                tool_call=tool_call,
                model_output=self._wait_model_output(result),
                client_output=result,
                pending_child_task_ids=pending_child_task_ids,
            )

        if isinstance(result, BaseModel):
            return _ToolResultInternal(
                tool_call=tool_call,
                model_output=self._stringify_for_model(serialize_for_model(result)),
                client_output=serialize_for_client(result),
                pending_child_task_ids=pending_child_task_ids,
            )

        if result is None:
            return _ToolResultInternal(
                tool_call=tool_call,
                model_output="",
                client_output=None,
                pending_child_task_ids=pending_child_task_ids,
            )

        # Plain types: str, dict, list, int, float, etc.
        return _ToolResultInternal(
            tool_call=tool_call,
            model_output=self._stringify_for_model(result),
            client_output=result,
            pending_child_task_ids=pending_child_task_ids,
        )

    def format_tool_result(
        self, tool_call_id: str, result: Any | _ToolResultInternal | Exception
    ) -> str:
        if isinstance(result, Exception):
            return (
                f'<tool_call_error tool="{tool_call_id}">\n'
                f"Error running tool:\n{result}\n</tool_call_error>"
            )
        elif isinstance(result, _ToolResultInternal):
            return (
                f'<tool_call_result tool="{tool_call_id}">\n'
                f"{result.model_output}\n</tool_call_result>"
            )
        else:
            return (
                f'<tool_call_result tool="{tool_call_id}">\n'
                f"{str(result)}\n</tool_call_result>"
            )

    def format_child_task_result(
        self, child_task_id: str, result: Any | Exception
    ) -> str:
        if isinstance(result, Exception):
            return (
                f'<sub_task_error sub_task_id="{child_task_id}">\n'
                f"Error running sub task:\n{result}\n</sub_task_error>"
            )
        else:
            return (
                f'<sub_task_result sub_task_id="{child_task_id}">\n'
                f"{str(result)}\n</sub_task_result>"
            )

    async def execute_tools(
        self,
        tool_calls: list[ChatCompletionMessageToolCall],
        agent_ctx: ContextType,
    ) -> ToolExecutionResults:
        """Execute tool calls and add results to messages"""
        new_messages: list[dict[str, Any]] = []
        pending_tool_call_ids: list[str] = []
        all_pending_child_task_ids: list[str] = []
        tool_call_results: list[
            tuple[ChatCompletionMessageToolCall, Any | Exception]
        ] = []

        # Run tools in parallel
        tasks = [
            self._tool_action_with_retry_and_progress(
                tc,
                agent_ctx,
            )
            for tc in tool_calls
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Add results to messages
        for tc, result in zip(tool_calls, results, strict=True):
            tool_call_results.append(
                (
                    tc,
                    result
                    if isinstance(result, Exception)
                    else result.client_output
                    if isinstance(result, _ToolResultInternal)
                    else result,
                )
            )

            if (
                isinstance(result, _ToolResultInternal)
                and result.pending_child_task_ids
            ):
                all_pending_child_task_ids.extend(result.pending_child_task_ids)

            if isinstance(result, Exception):
                logger.error(
                    f"Tool {tc.function.name} failed: {result}", exc_info=result
                )
                # Still need to add tool response to maintain conversation format
                content = self.format_tool_result(tc.id, result)
                new_messages.append(
                    {"role": "tool", "tool_call_id": tc.id, "content": content}
                )
            elif isinstance(result, _ToolResultInternal) and result.pending_result:
                pending_tool_call_ids.append(tc.id)
                # Invoke lifecycle callback for pending tool calls
                await self._safe_call(
                    self.on_pending_tool_call,
                    agent_ctx,
                    ExecutionContext.current(),
                    tc,
                )
            else:
                content = self.format_tool_result(tc.id, result)
                new_messages.append(
                    {"role": "tool", "tool_call_id": tc.id, "content": content}
                )

            # Propagate unrecoverable errors so the worker can fail the task.
            if isinstance(result, FatalAgentError):
                raise result

        return ToolExecutionResults(
            new_messages=new_messages,
            tool_call_results=tool_call_results,
            pending_tool_call_ids=pending_tool_call_ids,
            pending_child_task_ids=all_pending_child_task_ids,
        )

    async def run_turn(
        self,
        agent_ctx: ContextType,
    ) -> TurnCompletion[ContextType]:
        """Run a single turn. Override for custom logic."""

        # Lifecycle callback – turn start
        execution_ctx = ExecutionContext.current()
        await self._safe_call(self.on_turn_start, agent_ctx, execution_ctx)

        messages = self.prepare_messages(agent_ctx)

        response = await self._completion_with_retry_and_progress(
            agent_ctx,
            messages,
        )

        assistant_msg = {
            "role": "assistant",
            "content": response.choices[0].message.content,
            "tool_calls": (
                [
                    tc.model_dump()  # type: ignore
                    for tc in response.choices[0].message.tool_calls
                ]
                if response.choices[0].message.tool_calls
                else None
            ),
        }
        messages.append(assistant_msg)

        if self._is_done(response):
            output = self._extract_output(response)
            if self.verifier is not None:
                validated_output = self._validate_output_for_verifier(output)
                candidate_hash = self._compute_candidate_hash(validated_output)
                verifier_kwargs = self._resolve_verifier_injected_kwargs(
                    agent_ctx,
                    execution_ctx,
                )
                try:
                    verifier_result = await _invoke_callable_non_blocking(
                        self.verifier,
                        validated_output,
                        **verifier_kwargs,
                    )
                except VerificationRejected as rejection:
                    verification_state = agent_ctx.verification
                    attempts_counted = False
                    if verification_state.last_candidate_hash != candidate_hash:
                        verification_state.attempts_used += 1
                        attempts_counted = True
                    verification_state.last_candidate_hash = candidate_hash
                    verification_state.last_outcome = "rejected"

                    await self._publish_verification_event(
                        execution_ctx=execution_ctx,
                        agent_ctx=agent_ctx,
                        event_type="verification_rejected",
                        data={
                            "attempts_used": verification_state.attempts_used,
                            "max_attempts": self.verifier_max_attempts,
                            "attempt_counted": attempts_counted,
                            "message": rejection.message,
                            "code": rejection.code,
                            "metadata": rejection.metadata,
                        },
                    )

                    if verification_state.attempts_used >= self.verifier_max_attempts:
                        await self._publish_verification_event(
                            execution_ctx=execution_ctx,
                            agent_ctx=agent_ctx,
                            event_type="verification_exhausted",
                            data={
                                "attempts_used": verification_state.attempts_used,
                                "max_attempts": self.verifier_max_attempts,
                                "message": rejection.message,
                                "code": rejection.code,
                            },
                        )
                        raise FatalAgentError(
                            "Verification attempt budget exhausted "
                            f"({verification_state.attempts_used}/"
                            f"{self.verifier_max_attempts}): {rejection.message}"
                        ) from rejection

                    messages.append(
                        {
                            "role": "user",
                            "content": self._format_verification_feedback(rejection),
                        }
                    )
                    agent_ctx.messages = messages
                    agent_ctx.turn += 1
                    completion = TurnCompletion(
                        is_done=False,
                        context=agent_ctx,
                    )

                    await self._safe_call(
                        self.on_turn_end, agent_ctx, execution_ctx, completion
                    )
                    return completion
                except FatalAgentError:
                    agent_ctx.verification.last_outcome = "system_error"
                    raise
                except Exception:
                    agent_ctx.verification.last_outcome = "system_error"
                    raise

                agent_ctx.verification.last_candidate_hash = candidate_hash
                agent_ctx.verification.last_outcome = "passed"
                output = serialize_data(verifier_result)
                await self._publish_verification_event(
                    execution_ctx=execution_ctx,
                    agent_ctx=agent_ctx,
                    event_type="verification_passed",
                    data={
                        "attempts_used": agent_ctx.verification.attempts_used,
                        "max_attempts": self.verifier_max_attempts,
                    },
                )

            agent_ctx.output = output  # Store the final output in the agent context
            agent_ctx.messages = messages
            completion = TurnCompletion(
                is_done=True,
                context=agent_ctx,
                output=output,
            )

            # Lifecycle callback – turn end
            await self._safe_call(
                self.on_turn_end, agent_ctx, execution_ctx, completion
            )
            return completion

        # Handle tool calls and append results to messages
        tool_call_results: list[
            tuple[ChatCompletionMessageToolCall, Any | Exception]
        ] = []
        pending_tool_call_ids: list[str] = []
        pending_child_task_ids: list[str] = []
        if response.choices[0].message.tool_calls:
            # Filter to only function tool calls (the only type we support)
            function_tool_calls = [
                tc
                for tc in response.choices[0].message.tool_calls
                if isinstance(tc, ChatCompletionMessageFunctionToolCall)
            ]
            results = await self.execute_tools(
                function_tool_calls,
                agent_ctx,
            )
            messages += results.new_messages
            pending_tool_call_ids += results.pending_tool_call_ids
            pending_child_task_ids += results.pending_child_task_ids
            tool_call_results += results.tool_call_results

        agent_ctx.messages = messages
        agent_ctx.turn += 1
        completion = TurnCompletion(
            is_done=False,
            context=agent_ctx,
            pending_tool_call_ids=pending_tool_call_ids,
            pending_child_task_ids=pending_child_task_ids,
            tool_call_results=tool_call_results,
        )

        # Lifecycle callback – turn end
        await self._safe_call(self.on_turn_end, agent_ctx, execution_ctx, completion)
        return completion

    def process_deferred_tool_results(
        self,
        agent_ctx: ContextType,
        tool_call_results: list[tuple[str, Any]],
    ) -> TurnCompletion[ContextType]:
        updated_messages = agent_ctx.messages.copy()
        for tool_call_id, result in tool_call_results:
            if isinstance(result, Exception):
                logger.error(f"Tool {tool_call_id} failed: {result}", exc_info=result)

            content = self.format_tool_result(tool_call_id, result)
            updated_messages.append(
                {"role": "tool", "tool_call_id": tool_call_id, "content": content}
            )
        agent_ctx.messages = updated_messages

        return TurnCompletion(is_done=False, context=agent_ctx)

    def process_child_task_results(
        self,
        agent_ctx: ContextType,
        child_task_results: list[tuple[str, Any]],
    ) -> TurnCompletion[ContextType]:
        updated_messages = agent_ctx.messages.copy()
        formatted_child_task_results = []

        for child_task_id, result in child_task_results:
            if isinstance(result, Exception):
                logger.error(
                    f"Child task {child_task_id} failed: {result}", exc_info=result
                )
            formatted_child_task_results.append(
                self.format_child_task_result(child_task_id, result)
            )

        if formatted_child_task_results:
            joined_results = "\n\n".join(formatted_child_task_results)
            content = f"<sub_task_results>\n{joined_results}\n</sub_task_results>"
            updated_messages.append({"role": "assistant", "content": content})

        agent_ctx.messages = updated_messages

        return TurnCompletion(is_done=False, context=agent_ctx)

    # ===== Helper Methods ===== #
    def resolve_tools(self, agent_ctx: ContextType) -> list[dict[str, Any]]:
        tools = [
            tool.to_openai_tool_schema()
            for tool in self.tools
            if (
                tool.is_enabled(agent_ctx)
                if callable(tool.is_enabled)
                else tool.is_enabled
            )
        ]
        if self.final_output_tool:
            tools.append(self.final_output_tool)

        return tools

    def resolve_model(self, agent_ctx: ContextType) -> Model:
        model = self.model(agent_ctx) if callable(self.model) else self.model
        if not model:
            raise ValueError("No model is configured for agent")

        return model

    def resolve_model_settings(self, agent_ctx: ContextType) -> ResolvedModelSettings:
        return self.model_settings.resolve(agent_ctx)

    def resolve_instructions(self, agent_ctx: ContextType) -> str:
        """Resolve instructions, handling both string and callable instructions."""
        instructions = self.instructions

        if callable(instructions):
            sig = inspect.signature(instructions)
            params = list(sig.parameters.values())

            # Always pass agent_ctx as first argument
            args = [agent_ctx]

            # Check if any parameter has ExecutionContext type annotation
            has_execution_ctx = any(
                param.annotation
                and param.annotation != inspect.Parameter.empty
                and isinstance(param.annotation, type)
                and issubclass(param.annotation, ExecutionContext)
                for param in params
            )

            if has_execution_ctx:
                execution_ctx = ExecutionContext.current()
                args.append(cast(Any, execution_ctx))

            instructions = instructions(*args)

        return instructions or ""

    def _is_done(self, response: ChatCompletion) -> bool:
        """Check if agent should complete"""
        tool_calls = response.choices[0].message.tool_calls

        return (not tool_calls and self.output_type is None) or any(
            isinstance(tc, ChatCompletionMessageFunctionToolCall)
            and tc.function.name == "final_output"
            for tc in tool_calls or []
        )

    def _prepare_instructions(self, agent_ctx: ContextType) -> str:
        """Prepare instructions for LLM request. Override to customize."""

        instructions = self.resolve_instructions(agent_ctx)

        if self.max_turns:
            instructions += (
                f"\n\nYou must reach a final response "
                f"in {self.max_turns} turns or less."
            )
        if (
            self.output_type
            and isinstance(self.output_type, type)
            and issubclass(self.output_type, BaseModel)
        ):
            instructions += (
                "\n\nYour final response must be made using the 'final_output' tool."
            )

        return instructions

    def prepare_messages(self, agent_ctx: ContextType) -> list[dict[str, Any]]:
        """Prepare messages for LLM request. Override to customize."""
        if agent_ctx.turn == 0:
            messages = (
                [{"role": "system", "content": self._prepare_instructions(agent_ctx)}]
                if self.instructions
                else []
            )
            if agent_ctx.messages:
                messages.extend(
                    [message for message in agent_ctx.messages if message["content"]]
                )
            messages.append({"role": "user", "content": agent_ctx.query})
        else:
            messages = agent_ctx.messages

        return messages

    def _extract_output(
        self,
        response: ChatCompletion,
    ) -> str | dict[str, Any] | None:
        """Extract the final output from response content or tool calls."""
        content = response.choices[0].message.content
        tool_calls = response.choices[0].message.tool_calls

        if content:
            return content

        if tool_calls:
            for tool_call in tool_calls:
                if (
                    isinstance(tool_call, ChatCompletionMessageFunctionToolCall)
                    and tool_call.function.name == "final_output"
                ):
                    if self.parse_tool_args:
                        parsed: dict[str, Any] = json.loads(
                            tool_call.function.arguments
                        )
                        return parsed
                    else:
                        return tool_call.function.arguments

        return None

    def _extract_output_payload_for_verifier(
        self, output: str | dict[str, Any] | None
    ) -> dict[str, Any]:
        if isinstance(output, dict):
            return output
        if isinstance(output, str):
            try:
                parsed = json.loads(output)
            except json.JSONDecodeError as e:
                raise InvalidLLMResponseError(
                    "final_output arguments must be valid JSON object"
                ) from e
            if not isinstance(parsed, dict):
                raise InvalidLLMResponseError(
                    "final_output arguments must decode to a JSON object"
                )
            return parsed
        raise InvalidLLMResponseError("Missing final_output payload for verification")

    def _validate_output_for_verifier(
        self, output: str | dict[str, Any] | None
    ) -> BaseModel:
        if (
            self.output_type is None
            or not isinstance(self.output_type, type)
            or not issubclass(self.output_type, BaseModel)
        ):
            raise InvalidLLMResponseError(
                "Verifier requires output_type to be a Pydantic BaseModel subclass"
            )

        payload = self._extract_output_payload_for_verifier(output)
        try:
            return self.output_type.model_validate(payload)
        except Exception as e:
            raise InvalidLLMResponseError(
                f"final_output payload failed output_type validation: {e}"
            ) from e

    def _compute_candidate_hash(self, output_model: BaseModel) -> str:
        canonical_payload = json.dumps(
            output_model.model_dump(mode="json"),
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        return hashlib.sha256(canonical_payload.encode("utf-8")).hexdigest()

    def _resolve_verifier_injected_kwargs(
        self,
        agent_ctx: ContextType,
        execution_ctx: ExecutionContext,
    ) -> dict[str, Any]:
        verifier = self.verifier
        if verifier is None:
            return {}

        signature = inspect.signature(verifier)
        params = list(signature.parameters.values())
        if not params:
            raise TypeError("verifier must accept at least one argument for output")

        kwargs: dict[str, Any] = {}
        for param in params[1:]:
            param_name = param.name

            if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                continue

            annotation = param.annotation
            injected = False

            if param_name == "agent_ctx":
                kwargs[param_name] = agent_ctx
                injected = True
            elif (
                annotation is not inspect.Parameter.empty
                and isinstance(annotation, type)
                and issubclass(annotation, AgentContext)
            ):
                kwargs[param_name] = agent_ctx
                injected = True
            elif param_name == "execution_ctx":
                kwargs[param_name] = execution_ctx
                injected = True
            elif (
                annotation is not inspect.Parameter.empty
                and isinstance(annotation, type)
                and issubclass(annotation, ExecutionContext)
            ):
                kwargs[param_name] = execution_ctx
                injected = True

            if injected:
                continue
            if param.default is not inspect.Parameter.empty:
                continue
            raise TypeError(
                f"Unsupported required verifier parameter '{param_name}'. "
                "Only output (first arg), agent_ctx, and execution_ctx are supported."
            )

        return kwargs

    async def _publish_verification_event(
        self,
        *,
        execution_ctx: ExecutionContext,
        agent_ctx: ContextType,
        event_type: str,
        data: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        try:
            await execution_ctx.events.publish_event(
                AgentEvent(
                    event_type=event_type,
                    task_id=execution_ctx.task_id,
                    owner_id=execution_ctx.owner_id,
                    agent_name=self.name,
                    turn=agent_ctx.turn,
                    data=serialize_data(data) if data is not None else None,
                    error=error,
                )
            )
        except Exception:
            logger.exception("Failed to publish verification event", exc_info=True)

    def _format_verification_feedback(self, rejection: VerificationRejected) -> str:
        code_attr = (
            f' code="{rejection.code}"'
            if rejection.code is not None and rejection.code != ""
            else ""
        )
        lines = [
            f"<verification_rejected{code_attr}>",
            f"Summary: {rejection.message}",
        ]
        if rejection.metadata:
            metadata_json = json.dumps(
                serialize_data(rejection.metadata),
                sort_keys=True,
            )
            lines.append(f"Metadata: {metadata_json}")
        lines.append("</verification_rejected>")
        return "\n".join(lines)

    # ===== Core logic ===== #

    def get_execution_context(self) -> ExecutionContext:
        return ExecutionContext.current()

    @retry(max_attempts=3, delay=0.5)
    @publish_progress(func_name="completion")
    async def _completion_with_retry_and_progress(
        self,
        agent_ctx: ContextType,
        messages: list[dict[str, Any]],
    ) -> ChatCompletion:
        """Internal method that wraps completion with retry and progress publishing"""
        return await self.completion(
            agent_ctx,
            messages,
        )

    @retry(max_attempts=2, delay=0.25)
    @publish_progress(func_name="tool_action")
    async def _tool_action_with_retry_and_progress(
        self,
        tool_call: ChatCompletionMessageToolCall,
        agent_ctx: ContextType,
    ) -> _ToolResultInternal:
        """Internal method that wraps tool_action with retry and progress publishing"""
        return await self.tool_action(tool_call, agent_ctx)

    @publish_progress(func_name="run_turn")
    async def _run_turn_with_progress(
        self,
        agent_ctx: ContextType,
    ) -> TurnCompletion[ContextType]:
        """Internal method that wraps run_turn with progress publishing"""
        return await self.run_turn(agent_ctx)

    async def steer(
        self,
        messages: list[dict[str, Any]],
        agent_ctx: ContextType,
        execution_ctx: ExecutionContext,
    ) -> ContextType:
        agent_ctx.messages.extend(messages)
        return agent_ctx

    async def cancel(
        self, agent_ctx: ContextType, execution_ctx: ExecutionContext
    ) -> None:
        pass

    @final
    async def run_inline(
        self,
        agent_ctx: ContextType,
        event_handler: Callable[[AgentEvent], Awaitable[None]] | None = None,
    ) -> RunCompletion[ContextType]:
        """Run the agent in-line, without orchestration. For simple use-cases."""

        # ------------------------------------------------------------------
        # Lightweight, *local* execution helper.
        #
        # This mirrors the orchestrator/worker flow but **without** any Redis/
        # queue dependencies so developers can run agents directly in an async
        # context (e.g. notebooks, scripts, tests).
        # ------------------------------------------------------------------

        class InlineEventPublisher:  # pragma: no cover – simple stub
            """Minimal stub that satisfies the EventPublisher interface"""

            async def publish_event(self, event: Any) -> None:  # noqa: ANN401
                if event_handler:
                    await event_handler(event)

        started_at = datetime.now(timezone.utc)

        # Dummy execution context suitable for local runs.
        execution_ctx = ExecutionContext(
            task_id=str(uuid.uuid4()),
            owner_id=str(uuid.uuid4()),
            retries=0,
            iterations=agent_ctx.turn,
            events=InlineEventPublisher(),  # type: ignore[arg-type]
        )

        # Make the execution context available via the contextvar so all helper
        # utilities and decorators function as expected.
        token = execution_context.set(execution_ctx)

        try:
            # Lifecycle callback – run start
            await self._safe_call(self.on_run_start, agent_ctx, execution_ctx)

            turn_completion: TurnCompletion[ContextType]

            # Main turn-processing loop ------------------------------------------------
            while True:
                turn_completion = await self._run_turn_with_progress(agent_ctx)

                # Pending tool or child task results are not supported in local mode
                if (
                    turn_completion.pending_tool_call_ids
                    or turn_completion.pending_child_task_ids
                ):
                    raise RuntimeError(
                        "Pending tool/child task results are not "
                        "supported when running the agent locally."
                    )

                if turn_completion.is_done:
                    break

                # Defensive guard – respect max_turns in case the LLM never
                # reaches a final output.  `run_turn` increments `agent_ctx.turn`.
                if self.max_turns is not None and agent_ctx.turn >= self.max_turns:
                    logger.warning(
                        "Reached max_turns (%s) without final output, stopping.",
                        self.max_turns,
                    )
                    break

            finished_at = datetime.now(timezone.utc)

            run_completion: RunCompletion = RunCompletion(
                output=turn_completion.output,
                started_at=started_at,
                finished_at=finished_at,
            )

            # Lifecycle callback – run end (success)
            await self._safe_call(
                self.on_run_end,
                agent_ctx,
                execution_ctx,
                run_completion,
            )

            return run_completion

        except Exception as e:
            # Lifecycle callback – run end (failure)
            finished_at = datetime.now(timezone.utc)
            await self._safe_call(
                self.on_run_end,
                agent_ctx,
                execution_ctx,
                RunCompletion(
                    output=None,
                    error=e,
                    started_at=started_at,
                    finished_at=finished_at,
                ),
            )
            raise

        finally:
            # Always reset the execution context var to avoid leaking state.
            execution_context.reset(token)

    @final
    async def execute(
        self,
        agent_ctx: ContextType,
        execution_ctx: ExecutionContext,
    ) -> TurnCompletion[ContextType]:
        token = execution_context.set(execution_ctx)

        try:
            response = await self._run_turn_with_progress(agent_ctx)

            if response.is_done:
                await execution_ctx.events.publish_event(
                    AgentEvent(
                        event_type="agent_output",
                        task_id=execution_ctx.task_id,
                        owner_id=execution_ctx.owner_id,
                        agent_name=self.name,
                        turn=agent_ctx.turn,
                        data=response.output,
                    )
                )

            return response

        except Exception as e:
            logger.error(
                f"Agent {self.name} failed to execute turn {agent_ctx.turn}", exc_info=e
            )

            raise e

        finally:
            execution_context.reset(token)

    async def _safe_call(self, func: Callable[..., Any] | None, *args: Any) -> None:
        """Safely call a (possibly async) callback without letting it crash the agent.

        *All* exceptions are logged, but only non-fatal ones are swallowed. If the
        callback raises ``FatalAgentError`` we re-raise so the orchestrator can
        treat the task as a hard failure.
        """
        if func is None:
            return

        try:
            result = func(*args)
            if inspect.isawaitable(result):
                await result  # type: ignore[func-returns-value]
        except FatalAgentError as e:
            # Log and propagate so the caller can handle a fatal error.
            logger.error("FatalAgentError in lifecycle callback", exc_info=e)
            raise
        except Exception:
            # Non-fatal errors are logged but swallowed to avoid taking down the task.
            logger.exception("Error in lifecycle callback", exc_info=True)


class Agent(BaseAgent[AgentContext]):
    """Base agent class using AgentContext by default. For simple agents."""

    pass
